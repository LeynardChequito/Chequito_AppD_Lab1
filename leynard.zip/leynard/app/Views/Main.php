<?php
include 'Course.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STUDENT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>
<body>

    <div class="container mt-5">
    <div class="row">
            <div class="col-md-6">
        <h1 class="text-center">STUDENT INFORMATION</h1>
        <ul>
            <li>Read Carefully.</li>
            <li>Complete All Fields.</li>
            <li>Review Before Submitting.</li>
            
        </ul>
        <form action="<?= base_url("save") ?>" method="post">
            <?php if(isset($d['id'])){?>
                <input type="hidden" name="id" value="<?=$d['id']?>">
            <?php }?>
            
            <div class="form-group">
                <label for="StudName">Student Name</label> 
                <input type="text" class="form-control" id="StudName" name="StudName" required value="<?= isset($d['StudName']) ? $d['StudName'] : '' ?>">
            </div>
            
            <div class="form-group">
                <label for="StudGender">Gender</label>
                <select class="form-control" id="StudGender" name="StudGender" required>
                    <option value="Male" <?= isset($d['StudGender']) && $d['StudGender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= isset($d['StudGender']) && $d['StudGender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                </select>
            </div>

            <div class="form-group">
                <label for="StudCourse">Course</label>
                    <select class="form-control" id="StudCourse" name="StudCourse" required>
                        <?php
                        $selectedCourse = isset($d['StudCourse']) ? $d['StudCourse'] : '';
                        echo Course($selectedCourse);
                        ?>
                    </select>
            </div>
           
            <div class="form-group">
                <label for="StudSection">Student Section</label>
                <select class="form-control" id="StudSection" name="StudSection" required>
                    <option value="" <?= isset($d['StudSection']) && $d['StudSection'] === '' ? 'selected' : '' ?>>Class Section</option>
                    <option value="F1" <?= isset($d['StudSection']) && $d['StudSection'] === 'F1' ? 'selected' : '' ?>>F1</option>
                    <option value="F2" <?= isset($d['StudSection']) && $d['StudSection'] === 'F2' ? 'selected' : '' ?>>F2</option>
                    <option value="F3" <?= isset($d['StudSection']) && $d['StudSection'] === 'F3' ? 'selected' : '' ?>>F3</option>
                    <option value="F4" <?= isset($d['StudSection']) && $d['StudSection'] === 'F4' ? 'selected' : '' ?>>F4</option>
                    <option value="F5" <?= isset($d['StudSection']) && $d['StudSection'] === 'F5' ? 'selected' : '' ?>>F5</option>
                    <option value="F6" <?= isset($d['StudSection']) && $d['StudSection'] === 'F6' ? 'selected' : '' ?>>F6</option>
                </select></div>

            <div class="form-group">
                <label for="StudYear">Year Level</label>
                <input type="text" class="form-control" id="StudYear" name="StudYear" required value="<?= isset($d['StudYear']) ? $d['StudYear'] : '' ?>">
            </div>

            <input type="submit" class="btn btn-primary" value="Save">
        </form>
            </div>
        <div class="col-md-6">
                <table class="table table-bordered">
                <thead class="thead-dark">
                        <tr>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Course</th>
                            <th>Section</th>
                            <th>Year</th>
                            <th>Action</th>
                        </tr>
                    </thead>
            <tbody>
                <?php foreach($main as $main): ?>
                    <tr>
                        <td><?=$main['StudName'] ?></td>
                        <td><?=$main['StudGender'] ?></td>
                        <td><?=$main['StudCourse'] ?></td>
                        <td><?=$main['StudSection'] ?></td>
                        <td><?=$main['StudYear'] ?></td>
                        <td class="align-middle">
                            <a href="/update/<?=$main['id']?>" class="btn btn-info btn-sm">Edit</a>
                            <a href="/delete/<?=$main['id']?>" class="btn btn-danger btn-sm">Delete</a> 
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-KyZXEAg3QhqLMpG8r+3X6bs5Jv5F5d8Wz6W5E5LZ+6z9zKjAC5z5Zrp6jI8zuKfGd5" crossorigin="anonymous"></script>
</body>
</html>