<?php
// Course.php

function Course($selectedCourse = '') {
    $courseOptions = [
        "BSED Major in English",
        "BSED Major in Math",
        "BSED Major in Filipino",
        "BSED Major in Science",
        "BTVTED Major in Food Services Management",
        "BTVTED Major in Automotive Technology",
        "BTVTED Major in Electrical Technology",
        "BTVTED Major in Electronics Technology",
        "BTVTED Major in Drafting Technology",
        "BTVTED Major in Garments and Fashion Design Technology",
        "Bachelor of Science in Criminology",
        "Bachelor of Arts in Psychology",
        "Bachelor of Arts in English Language",
        "Bachelor of Science in Information Technology",
        "Bachelor of Science in Hospitality Management",
        "Bachelor of Science in Tourism Management",
    ];

    $options = '';

    foreach ($courseOptions as $course) {
        $selected = ($selectedCourse === $course) ? 'selected' : '';
        $options .= "<option value=\"$course\" $selected>$course</option>";
    }

    return $options;
}
?>




<!-- <div class="form-group">
                <label for="StudCourse">Course</label>
                <select class="form-control" id="StudCourse" name="StudCourse" required>
                    <optgroup>
                        <option value="BSED Major in English" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in English' ? 'selected' : '' ?>>BSED Major in English</option>
                        <option value="BSED Major in Math" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Math' ? 'selected' : '' ?>>BSED Major in Math</option>
                        <option value="BSED Major in Filipino" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Filipino' ? 'selected' : '' ?>>BSED Major in Filipino</option>
                        <option value="BSED Major in Science" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BSED Major in Science' ? 'selected' : '' ?>>BSED Major in Science</option>
                    </optgroup>

                    <optgroup label="">
                        <option value="BTVTED Major in Food Services Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Food Services Management' ? 'selected' : '' ?>>BTVTED Major in Food Services Management</option>
                        <option value="BTVTED Major in Automotive Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Automotive Technology' ? 'selected' : '' ?>>BTVTED Major in Automotive Technology</option>
                        <option value="BTVTED Major in Electrical Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Electrical Technology' ? 'selected' : '' ?>>BTVTED Major in Electrical Technology</option>
                        <option value="BTVTED Major in Electronics Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Electronics Technology' ? 'selected' : '' ?>>BTVTED Major in Electronics Technology</option>
                        <option value="BTVTED Major in Drafting Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'BTVTED Major in Drafting Technology' ? 'selected' : '' ?>>BTVTED Major in Drafting Technology</option>
                        <option value="BTVTED Major in Garments and Fasion Design Technology" <?= isset($d['StudCourse']) && 
                        $d['StudCourse'] === 'BTVTED Major in Garments and Fasion Design Technology' ? 'selected' : '' ?>>BTVTED Major in Garments and Fasion Design Technology</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Science in Criminology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Criminology' ? 'selected' : '' ?>>Bachelor of Science in Criminology</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Arts in Psychology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Arts in Psychology' ? 'selected' : '' ?>>Bachelor of Arts in Psychology</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Arts in English Language" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Arts in English Language' ? 'selected' : '' ?>>Bachelor of Arts in English Language</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Science in Information Technology" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Information Technology' ? 'selected' : '' ?>>Bachelor of Science in Information Technology</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Science in Hospitality Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Hospitality Management' ? 'selected' : '' ?>>Bachelor of Science in Hospitality Management</option>
                        </optgroup>
    
                        <optgroup label="">
                        <option value="Bachelor of Science in Tourism Management" <?= isset($d['StudCourse']) && $d['StudCourse'] === 'Bachelor of Science in Tourism Management' ? 'selected' : '' ?>>Bachelor of Science in Tourism Management</option>
                        </optgroup>
    
                        <optgroup label=""></optgroup>
                    </select>
                </div> -->